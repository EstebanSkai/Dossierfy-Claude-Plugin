# Investigación: Cómo añadir Skills al plugin Dossierfy para Claude

> **Propósito:** Documento de referencia para implementar Skills en el plugin Dossierfy (`.mcpb`).
> Captura toda la investigación sobre la especificación de Skills de Claude, la estructura de archivos requerida,
> y el plan concreto de skills propuestas para este plugin.

---

## Tabla de Contenidos

1. [¿Qué son los Skills en plugins de Claude?](#1-qué-son-los-skills-en-plugins-de-claude)
2. [Formato de archivo y schema](#2-formato-de-archivo-y-schema)
3. [Estructura de directorios](#3-estructura-de-directorios)
4. [Mecánica de activación dinámica](#4-mecánica-de-activación-dinámica)
5. [Skills propuestos para el plugin Dossierfy](#5-skills-propuestos-para-el-plugin-dossierfy)
6. [Diferencias clave: opencode skills vs Claude plugin skills](#6-diferencias-clave-opencode-skills-vs-claude-plugin-skills)
7. [El desafío neo4j-local para secciones-diana](#7-el-desafío-neo4j-local-para-secciones-diana)
8. [Convención SETUP.md](#8-convención-setupmd)
9. [Validación y pruebas](#9-validación-y-pruebas)
10. [Enlaces de referencia](#10-enlaces-de-referencia)

---

## 1. ¿Qué son los Skills en plugins de Claude?

Los **Skills** son instrucciones específicas para tareas que Claude activa dinámicamente según el contexto de la conversación. Siguen la especificación abierta [Agent Skills](https://agentskills.io/specification) y utilizan **divulgación progresiva**: solo el nombre y la descripción (~100 tokens) se cargan al inicio de la sesión; el cuerpo completo se carga únicamente cuando es relevante.

A diferencia de los system prompts estáticos, los skills se cargan **bajo demanda**.

### Comparativa de conceptos relacionados

| Concepto | Propósito |
|---|---|
| **Skills** | Procedimientos específicos por tarea, cargados dinámicamente |
| **Plugins** | Paquetes compartibles que agrupan skills + connectors + commands + sub-agents |
| **Projects** | Conocimiento de fondo estático, siempre cargado |
| **Custom Instructions** | Preferencias amplias aplicadas a todas las conversaciones |
| **MCP** | Conecta a Claude con servicios externos |

---

## 2. Formato de archivo y schema

Un skill es un **directorio** con el nombre del skill que contiene un archivo `SKILL.md`. El nombre del directorio se convierte en el comando de invocación: `brand-guidelines/` → `/plugin-name:brand-guidelines`.

### Formato: YAML frontmatter + cuerpo Markdown

**Ejemplo mínimo:**

```markdown
---
name: ema-variation-classifier
description: Classify EMA post-authorisation variations (Type IA/IB/II). Use when user describes a drug manufacturing, specification, or site change needing regulatory typification.
---

# EMA Variation Classifier
[instrucciones...]
```

### Campos del frontmatter

| Campo | Obligatorio | Descripción |
|---|---|---|
| `name` | Recomendado | Minúsculas, guiones, máx. 64 chars. Debe coincidir con el nombre del directorio |
| `description` | ⚠️ **CRÍTICO** | Máx. **200 chars en Claude.ai** (1024 en la spec abierta). Es lo que Claude usa para decidir cuándo auto-activar el skill |
| `when_to_use` | Opcional | Contexto adicional sobre cuándo activar el skill |
| `disable-model-invocation` | Opcional | `true` = solo el usuario puede invocar (para skills con efectos secundarios o destructivos) |
| `user-invocable` | Opcional | `false` = oculto del menú `/`, solo Claude puede invocar |
| `allowed-tools` | Opcional | Herramientas pre-aprobadas para este skill |
| `disallowed-tools` | Opcional | Herramientas deshabilitadas mientras el skill está activo |
| `context` | Opcional | `fork` para crear un subagente con contexto aislado |
| `license` | Opcional | Licencia del skill |
| `compatibility` | Opcional | Plataformas compatibles (ej. `claude`, `opencode`) |
| `metadata` | Opcional | Mapa arbitrario de clave-valor |

> ⚠️ **Advertencia crítica:** El campo `description` está limitado a **200 caracteres** en Claude.ai, aunque la especificación abierta permite hasta 1024. Diseñar siempre dentro del límite de 200 chars para máxima compatibilidad.

---

## 3. Estructura de directorios

```
extension/                         ← raíz del plugin (ya existe)
├── manifest.json                  ← manifiesto del plugin (ya existe) ✅
├── SETUP.md                       ← opcional: guía de configuración en el momento de instalar
└── skills/
    ├── skill-name-1/
    │   ├── SKILL.md               ← REQUERIDO: frontmatter + instrucciones
    │   ├── scripts/               ← opcional: scripts Python/Bash/JS
    │   ├── references/            ← opcional: docs detallados cargados bajo demanda
    │   └── examples/              ← opcional: ejemplos de inputs/outputs
    └── skill-name-2/
        └── SKILL.md
```

✅ Los skills en `skills/` son **auto-descubiertos** — no se necesita registrarlos en `manifest.json`.

### Estado actual del plugin Dossierfy

```
extension/                         ← directorio del plugin
├── manifest.json                  ✅ existe
├── server/                        ✅ servidor MCP Node.js
├── dossierfy.mcpb                 ✅ bundle del plugin
└── skills/                        ❌ NO EXISTE AÚN — hay que crearlo
```

---

## 4. Mecánica de activación dinámica

### Ciclo de vida de un skill

1. **Al inicio de sesión:** todos los campos `name` + `description` de todos los skills se inyectan en el contexto (~100 tokens cada uno)
2. **Durante la conversación:** Claude razona sobre la intención del usuario y la compara con las descripciones
3. **Cuando hay coincidencia:** el cuerpo completo del `SKILL.md` se carga en el contexto
4. **El contenido permanece** en el contexto durante el resto de la sesión
5. **Después de la compactación de contexto:** los skills invocados más recientemente se re-adjuntan (hasta 5.000 tokens cada uno, presupuesto combinado de 25.000 tokens)

### Consejos para una activación fiable

- **Ser específico:** incluir palabras clave que los usuarios puedan usar
- **Mencionar ejemplos:** "Use when the user asks about X" o "Use when the user describes Y"
- **Mantenerse bajo 200 caracteres** para Claude.ai
- **Incluir el dominio**: mencionar el dominio de aplicación (ej. "pharma", "EMA", "CTD") para evitar falsos positivos

### Invocación manual

Además de la activación automática, los skills pueden invocarse manualmente:

```
/dossierfy:ema-variation-classifier
/dossierfy:ema-qa-validator
/dossierfy:document-impact-analysis
```

---

## 5. Skills propuestos para el plugin Dossierfy

### Skill 1: `ema-variation-classifier`

| Campo | Valor |
|---|---|
| **Directorio** | `skills/ema-variation-classifier/` |
| **Fuente** | Adaptar desde `~/.opencode/skills/dossierfy-v3-2/SKILL.md` |
| **Propósito** | Tipificación de variaciones post-autorización EMA usando el grafo MCP de Dossierfy |
| **Dependencia MCP** | ✅ Solo Dossierfy MCP (el servidor propio del plugin) — autocontenido |

**Description propuesta (≤200 chars):**
```
Classify EMA post-authorisation variations (Type IA/IB/II) for pharma changes. Use when user describes a drug manufacturing, specification, or site change.
```
> Longitud: ~155 chars ✅

**Pasos de implementación:**
1. Copiar contenido de `~/.opencode/skills/dossierfy-v3-2/SKILL.md`
2. Actualizar frontmatter: eliminar/cambiar `compatibility: opencode` → `compatibility: claude`
3. Ajustar `description` para que tenga ≤200 chars
4. Verificar que todas las llamadas a herramientas usen las tools del servidor Dossierfy

---

### Skill 2: `ema-qa-validator`

| Campo | Valor |
|---|---|
| **Directorio** | `skills/ema-qa-validator/` |
| **Fuente** | Adaptar desde `~/.opencode/skills/dossierfy-qa/SKILL.md` |
| **Propósito** | Tipificación EMA con paso de validación Q&A obligatorio contra nodos `QAEntryModel` |
| **Dependencia MCP** | ✅ Solo Dossierfy MCP — autocontenido (requiere nodos `QAEntryModel` en el grafo) |

**Description propuesta (≤200 chars):**
```
Classify EMA variations with Q&A validation. Use when user wants typification verified against EMA Q&A entries stored in the Dossierfy graph.
```
> Longitud: ~143 chars ✅

**Pasos de implementación:**
1. Copiar contenido de `~/.opencode/skills/dossierfy-qa/SKILL.md`
2. Mismo tratamiento que `ema-variation-classifier` para el frontmatter
3. Verificar que el flujo Q&A usa herramientas disponibles en el MCP de Dossierfy

---

### Skill 3: `document-impact-analysis` ⚠️ Complejo

| Campo | Valor |
|---|---|
| **Directorio** | `skills/document-impact-analysis/` |
| **Fuente** | Adaptar desde `~/.opencode/skills/secciones-diana/SKILL.md` |
| **Propósito** | Identificar qué secciones de documentos CTD se ven afectadas por un `VariationCode` dado |
| **Dependencia MCP** | ⚠️ **DOS MCPs** — Dossierfy MCP + neo4j-local MCP (externo, independiente) |

**Description propuesta (≤200 chars):**
```
Identify CTD document sections affected by a classified variation code. Use after typification to map which document texts need updating. Requires neo4j-local MCP.
```
> Longitud: ~163 chars ✅

> ⚠️ **Complejidad:** Este skill depende de un segundo MCP (`neo4j-local`) que el usuario debe ejecutar de forma independiente. Ver [Sección 7](#7-el-desafío-neo4j-local-para-secciones-diana) para las opciones de manejo.

**Prerequisito:** El usuario debe haber obtenido previamente un `VariationCode` mediante `ema-variation-classifier` o `ema-qa-validator`.

---

## 6. Diferencias clave: opencode skills vs Claude plugin skills

| Aspecto | Opencode Skills | Claude Plugin Skills |
|---|---|---|
| Campo `compatibility` | `opencode` | Eliminar o cambiar a `claude` |
| Límite `description` | 1024 chars | **200 chars máximo** |
| Herramientas disponibles | Cualquier MCP configurado | Solo las tools del MCP del plugin |
| Invocación | Auto por contexto | Auto + `/plugin-name:skill-name` |
| Ubicación | `~/.opencode/skills/` | `extension/skills/` |
| Descubrimiento | Configuración de opencode | Auto-descubierto en directorio `skills/` |

### Cambios de frontmatter al portar desde opencode

```yaml
# ANTES (opencode)
---
name: mi-skill
description: >
  Descripción larga de más de 200 caracteres que explicaba
  múltiples casos de uso y condiciones detalladas de activación...
compatibility: opencode
---

# DESPUÉS (Claude plugin)
---
name: mi-skill
description: Descripción concisa ≤200 chars con palabras clave de activación.
compatibility: claude
---
```

---

## 7. El desafío neo4j-local para secciones-diana

El skill `document-impact-analysis` (adaptado de `secciones-diana`) depende de **dos MCPs**:

1. ✅ **Dossierfy MCP** — el servidor propio del plugin, disponible automáticamente
2. ⚠️ **neo4j-local MCP** — un MCP de Neo4j local separado que el usuario ejecuta de forma independiente

### Opciones para manejar esta dependencia

#### Opción A: Enfoque SETUP.md (recomendado)

Incluir un `SETUP.md` en la raíz del plugin que guíe al usuario para configurar el MCP `neo4j-local` al instalar el plugin. El skill ya maneja internamente el caso en que la herramienta no está disponible (degradación elegante).

**Ventajas:** Simple, no rompe el plugin si el usuario no tiene `neo4j-local`.
**Desventajas:** Requiere acción manual del usuario.

#### Opción B: Segundo conector MCP en manifest.json

Añadir una segunda entrada `mcp_config` en `manifest.json` para `neo4j-local`, con `neo4j_url` y `neo4j_password` configurables en `user_config`.

```json
{
  "mcp_config": [
    { "name": "dossierfy", "command": "..." },
    {
      "name": "neo4j-local",
      "command": "...",
      "user_config": {
        "neo4j_url": { "type": "string", "required": false },
        "neo4j_password": { "type": "string", "required": false, "secret": true }
      }
    }
  ]
}
```

**Ventajas:** Integración nativa, el plugin gestiona la configuración.
**Desventajas:** Aumenta la complejidad del plugin; requiere que el usuario tenga Neo4j corriendo.

#### Opción C: Excluir del plugin (solo opencode)

Mantener `secciones-diana` exclusivamente como skill de opencode hasta que el plugin soporte orquestación multi-MCP de forma nativa.

**Ventajas:** Sin complejidad adicional en el plugin.
**Desventajas:** Feature no disponible para usuarios del plugin Claude.

### Recomendación

Implementar **Opción A** en primera versión: incluir el skill con instrucciones de degradación elegante y un `SETUP.md` que guíe la configuración opcional de `neo4j-local`. Si hay demanda, escalar a Opción B.

---

## 8. Convención SETUP.md

La documentación de Anthropic menciona `SETUP.md` como convención para guiar la configuración del MCP en el momento de instalación. Para Dossierfy, este archivo podría incluir:

```markdown
# Dossierfy Plugin Setup

## Configuración básica
La API key de Dossierfy se configura automáticamente durante la instalación
a través del campo `api_key` en `user_config`.

## Función opcional: Análisis de impacto en documentos CTD

Para usar el skill `document-impact-analysis`, necesitas tener configurado
el MCP `neo4j-local` con acceso a tu base de datos de documentos CTD.

### Pasos:
1. Instala el servidor neo4j MCP: `npm install -g @neo4j/mcp-server`
2. Configura las variables de entorno: `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`
3. Inicia el servidor: `neo4j-mcp-server`
4. En Claude, verifica la conexión con: `/dossierfy:document-impact-analysis`

Sin esta configuración, los skills `ema-variation-classifier` y
`ema-qa-validator` funcionan completamente sin necesidad de neo4j-local.
```

---

## 9. Validación y pruebas

### Comandos de validación

```bash
# Validar estructura del plugin
claude plugin validate ./extension

# Probar localmente
claude --plugin-dir ./extension

# Recargar durante desarrollo (dentro de Claude)
/reload-plugins
```

### Checklist antes de publicar

- [ ] Todos los `SKILL.md` tienen frontmatter YAML válido
- [ ] Cada `description` tiene ≤200 caracteres
- [ ] El campo `name` coincide con el nombre del directorio
- [ ] Sin campo `compatibility: opencode` (cambiar a `claude` o eliminar)
- [ ] Las referencias a herramientas MCP usan nombres de tools del servidor Dossierfy
- [ ] El `SETUP.md` documenta la dependencia opcional de `neo4j-local`
- [ ] Estructura `skills/` presente en la raíz del plugin

### Estructura final esperada

```
extension/
├── manifest.json                          ✅ existe
├── server/                                ✅ existe
├── SETUP.md                               🔲 crear
└── skills/
    ├── ema-variation-classifier/
    │   └── SKILL.md                       🔲 crear (adaptar dossierfy-v3-2)
    ├── ema-qa-validator/
    │   └── SKILL.md                       🔲 crear (adaptar dossierfy-qa)
    └── document-impact-analysis/
        └── SKILL.md                       🔲 crear (adaptar secciones-diana)
```

---

## 10. Enlaces de referencia

| Recurso | URL |
|---|---|
| Skills overview | https://claude.com/docs/skills/overview |
| Creating skills | https://claude.com/docs/skills/how-to |
| Plugin submission | https://claude.com/docs/plugins/submit |
| Claude Code skills reference | https://code.claude.com/docs/en/skills |
| Agent Skills open standard | https://agentskills.io/specification |
| Example skills (GitHub) | https://github.com/anthropics/skills/tree/main/skills |

### Fuentes opencode ya disponibles en el proyecto

| Skill | Ruta |
|---|---|
| `dossierfy-v3-2` | `~/.opencode/skills/dossierfy-v3-2/SKILL.md` |
| `dossierfy-qa` | `~/.opencode/skills/dossierfy-qa/SKILL.md` |
| `secciones-diana` | `~/.opencode/skills/secciones-diana/SKILL.md` |

---

*Documento generado el 29 de junio de 2026. Para preguntas sobre la implementación, consultar la especificación oficial en https://agentskills.io/specification.*
